-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jan 15, 2016 at 09:50 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `thiingdb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `lotto`
-- 

CREATE TABLE `lotto` (
  `code_id` int(11) NOT NULL auto_increment,
  `f_year` int(11) NOT NULL,
  `f_mon` int(11) NOT NULL,
  `f_round` int(11) NOT NULL,
  `f_date` date NOT NULL,
  `f_2_1` int(11) NOT NULL,
  `f_2_2` int(11) NOT NULL,
  `f_1_4` int(11) NOT NULL,
  `f_1_5` int(11) NOT NULL,
  `f_1_6` int(11) NOT NULL,
  `f_1_first` varchar(3) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`code_id`),
  KEY `f_year` (`f_year`),
  KEY `f_mon` (`f_mon`),
  KEY `f_round` (`f_round`),
  KEY `f_date` (`f_date`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `lotto`
-- 

INSERT INTO `lotto` VALUES (1, 2014, 1, 1, '2014-01-01', 7, 8, 5, 2, 1, '147');
INSERT INTO `lotto` VALUES (2, 2014, 1, 2, '2014-01-16', 8, 9, 5, 9, 8, '547');
INSERT INTO `lotto` VALUES (3, 2014, 2, 1, '2014-02-01', 3, 4, 3, 3, 8, '541');
INSERT INTO `lotto` VALUES (4, 2014, 2, 2, '2014-02-16', 8, 3, 5, 4, 7, '452');

-- --------------------------------------------------------

-- 
-- Table structure for table `mbrand`
-- 

CREATE TABLE `mbrand` (
  `brand_id` int(11) NOT NULL auto_increment,
  `name_th` varchar(250) collate utf8_unicode_ci NOT NULL,
  `name_en` varchar(250) collate utf8_unicode_ci NOT NULL,
  `logo` varchar(250) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`brand_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=35 ;

-- 
-- Dumping data for table `mbrand`
-- 

INSERT INTO `mbrand` VALUES (18, 'Samsung', 'Samsung', '');
INSERT INTO `mbrand` VALUES (31, 'BenQ', 'BenQ', '');
INSERT INTO `mbrand` VALUES (30, 'Dell', 'Dell', '');
INSERT INTO `mbrand` VALUES (11, 'LG', 'LG', '');
INSERT INTO `mbrand` VALUES (29, 'Lenovo', 'Lenovo', '');
INSERT INTO `mbrand` VALUES (7, 'Apple', 'Apple', '');
INSERT INTO `mbrand` VALUES (21, 'Nokia', 'Mokia', '');
INSERT INTO `mbrand` VALUES (22, 'Acer', 'Acer', '');
INSERT INTO `mbrand` VALUES (23, 'IMobile', 'IMobile', '');
INSERT INTO `mbrand` VALUES (32, 'Blackberry', 'Blackberry', '');
INSERT INTO `mbrand` VALUES (25, 'Azus', 'Azus', '');
INSERT INTO `mbrand` VALUES (26, 'Dtac', 'Dtac', '');
INSERT INTO `mbrand` VALUES (27, 'Motolola', 'Motolola', '');
INSERT INTO `mbrand` VALUES (24, 'HTC', 'HTC', '');
INSERT INTO `mbrand` VALUES (28, 'Ais', 'Ais', '');
INSERT INTO `mbrand` VALUES (33, 'Huawei', 'Huawei', '');
INSERT INTO `mbrand` VALUES (34, 'Panasonic', 'Panasonic', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `mproduct`
-- 

CREATE TABLE `mproduct` (
  `product_id` int(11) NOT NULL auto_increment,
  `brand_id` int(11) NOT NULL,
  `product_name` varchar(250) collate utf8_unicode_ci NOT NULL,
  `series` varchar(100) collate utf8_unicode_ci NOT NULL,
  `weight` double NOT NULL,
  `screen_size` double NOT NULL,
  `sim` int(11) NOT NULL,
  `batt` double NOT NULL,
  `cpu_core` double NOT NULL,
  `cpu_vol` double NOT NULL,
  `ram` double NOT NULL,
  `rom_in` double NOT NULL,
  `rom_ext` double NOT NULL,
  `cam_f` double NOT NULL,
  `cam_b` double NOT NULL,
  `price_url` varchar(250) collate utf8_unicode_ci default NULL,
  `prod_url` varchar(250) collate utf8_unicode_ci default NULL,
  `comment` text collate utf8_unicode_ci,
  `relatelink` text collate utf8_unicode_ci,
  `embed` text collate utf8_unicode_ci,
  `last_update` date default NULL,
  PRIMARY KEY  (`product_id`),
  KEY `brand_id` (`brand_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

-- 
-- Dumping data for table `mproduct`
-- 

INSERT INTO `mproduct` VALUES (15, 25, 'Asuz', 'Asuz', 200, 4.5, 1, 10000, 1, 6, 1, 16, 32, 5.5, 16, '5500', '1', '', '1', '1', '2016-01-14');
INSERT INTO `mproduct` VALUES (4, 24, '999', '1', 1, 1, 1, 1, 1, 20, 0, 0, 0, 0, 0, '111', '111', '1111', '111', '111', '2016-01-13');
INSERT INTO `mproduct` VALUES (16, 22, 'Acer Liquid', 'Acer Liquid', 200, 6.5, 1, 4500, 1, 16, 16, 16, 16, 5, 16, '1000', '1', '', '1', '1', '2016-01-14');
INSERT INTO `mproduct` VALUES (10, 7, 'IPhone5', 'IPhone5s', 1.8, 5.4, 1, 3000, 1, 1.5, 1.5, 16, 0, 4, 8, '20000', '0.5', '', '1', '1', '2016-01-13');
INSERT INTO `mproduct` VALUES (11, 21, 'N 95', '1', 2, 3, 4, 6, 7, 8, 5, 9, 10, 11, 12, '13', '14', '15', '16', '17', '2016-01-13');
INSERT INTO `mproduct` VALUES (12, 7, 'Iphone', 'Iphone 6s', 150, 5.5, 1, 30000, 2, 45, 16, 64, 64, 8, 16, '25000', '1', '', '', '1', '2016-01-14');
INSERT INTO `mproduct` VALUES (13, 18, 'Samsung', 'Galaxy s5', 250, 6.5, 1, 35000, 4, 1.8, 4, 64, 128, 6, 15, '26000', '1', '', '', '', '2016-01-14');
INSERT INTO `mproduct` VALUES (14, 24, 'zenfone', 'zenfone 2', 2000, 5.6, 1, 60000, 1, 1, 1, 1, 1, 16, 60, '6000', '1', '1', '1', '1', '2016-01-14');
INSERT INTO `mproduct` VALUES (17, 28, 'Lava Pro', 'Lava Pro', 1500, 3.5, 2, 1500, 0, 0, 0, 16, 0, 2, 8, '890', '1', '', '', '', '2016-01-15');
INSERT INTO `mproduct` VALUES (18, 23, 'IQ Z PRO', 'IQ Z PRO', 250, 5.5, 2, 5000, 1, 6, 16, 16, 16, 5, 16, '3500', '1', '', '', '', '2016-01-15');
INSERT INTO `mproduct` VALUES (19, 7, 'Iphone', 'Iphone 4', 250, 4.5, 1, 3000, 1, 16, 4, 16, 32, 5, 8, '6000', '1', '', '', '', '2016-01-15');

-- --------------------------------------------------------

-- 
-- Table structure for table `mseries`
-- 

CREATE TABLE `mseries` (
  `series_id` int(11) NOT NULL auto_increment,
  `brand_id` int(11) NOT NULL,
  `name_th` varchar(250) collate utf8_unicode_ci NOT NULL,
  `name_en` varchar(250) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`series_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `mseries`
-- 

INSERT INTO `mseries` VALUES (1, 17, 'aasasas', 'asasas');
INSERT INTO `mseries` VALUES (2, 18, 'Galaxy', 'Galaxy');
INSERT INTO `mseries` VALUES (3, 21, 'Acer', 'Acer');
